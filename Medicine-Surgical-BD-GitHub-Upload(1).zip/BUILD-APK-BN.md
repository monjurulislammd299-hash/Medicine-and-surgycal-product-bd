# APK তৈরি করার নিয়ম (বাংলা)

এই ZIP-এ Medicine & Surgical BD Android WebView অ্যাপের সোর্স কোড, আগের ওয়েব অ্যাপ, Firebase bridge, Firestore rules এবং GitHub Actions build workflow আছে।

## GitHub দিয়ে APK তৈরি
1. ZIP Extract করে সব ফাইল আপনার GitHub repository-তে আপলোড করুন (root-এ `settings.gradle` থাকতে হবে)।
2. Firebase ব্যবহার করতে Firebase Console থেকে Android app `com.medicinesurgical.store` যোগ করে `google-services.json` ডাউনলোড করুন এবং `app/google-services.json` নামে রাখুন।
3. Firebase Authentication, Cloud Firestore এবং প্রয়োজন হলে Cloud Functions চালু করুন। Firestore rules যাচাই করে deploy করুন; production-এ test rules ব্যবহার করবেন না।
4. GitHub-এর **Actions → Build Android APK → Run workflow** চাপুন।
5. Build সফল হলে `medicine-surgical-debug-apk` artifact ডাউনলোড করে ZIP Extract করুন। `app-debug.apk` ফোনে ইনস্টল করুন।

## গুরুত্বপূর্ণ
- এটি Android Studio/GitHub Actions-এ build করার source project; এই ZIP নিজে APK নয়।
- Firebase project configuration না দিলে APK compile হতে পারে, কিন্তু অনলাইন Firebase login/database চালু হবে না।
- Demo catalogue বা ওষুধের তালিকা লাইভ বিক্রির আগে লাইসেন্স, DGDA নিয়ম এবং ফার্মাসিস্টের যাচাই আবশ্যক। প্রেসক্রিপশন-নির্ভর ওষুধ যথাযথ প্রেসক্রিপশন যাচাই ছাড়া বিক্রি করবেন না।
