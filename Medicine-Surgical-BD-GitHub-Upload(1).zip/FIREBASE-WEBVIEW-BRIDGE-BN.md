# Firebase WebView Auth Bridge — বাংলা নির্দেশনা

এই আপডেটে Android WebView-তে `NativeAuth` নামে সীমিত Firebase Authentication bridge যোগ হয়েছে। এটি কেবল bundled `file:///android_asset/index.html` পেজের জন্য। বাহ্যিক ওয়েবসাইট WebView-তে খোলা হয় না।

## JavaScript থেকে ব্যবহার

`index.html`-এর script অংশে নিচের callback যোগ করুন:

```javascript
window.onNativeAuthResult = function (raw) {
  const result = JSON.parse(raw);
  if (result.success && result.admin) {
    // এখানে Admin dashboard দেখান
    console.log('Admin login:', result.email);
  } else {
    // এখানে নিরাপদভাবে error দেখান
    console.warn(result.message);
  }
};
```

Login form submit হলে Android APK-তে:

```javascript
if (window.NativeAuth) {
  NativeAuth.signIn(email, password);
} else {
  alert('এই Login সুবিধার জন্য Android APK প্রয়োজন');
}
```

Session যাচাই ও logout:

```javascript
NativeAuth.checkSession();
NativeAuth.signOut();
```

## প্রয়োজনীয় শর্ত

1. Firebase Console-এ Android app-এর package name অবশ্যই `com.medicinesurgical.store` হতে হবে।
2. ডাউনলোড করা `google-services.json` ফাইলটি `app/google-services.json`-এ রাখুন। এই ফাইলটি না থাকলে Google Services Gradle plugin build ব্যর্থ করবে।
3. Firebase Authentication-এ Email/Password provider চালু করুন এবং Admin user তৈরি করুন।
4. Admin user-কে trusted server/Admin SDK থেকে `admin: true` custom claim দিতে হবে। Android client থেকে claim দেওয়া যাবে না।
5. Admin claim সেট করার পর নতুন ID token পেতে আবার login করুন।
6. Firestore Rules-এও `request.auth.token.admin == true` যাচাই থাকতে হবে। UI-তে Admin লুকানো/দেখানো নিরাপত্তার বিকল্প নয়।

## সীমাবদ্ধতা ও সতর্কতা

- এই আপডেট native Firebase Auth bridge যোগ করে; HTML login form-এ callback wiring এবং Firestore product/order CRUD এখনো আলাদা কাজ।
- `google-services.json` ছাড়া এই প্রকল্পের Firebase build বা বাস্তব login পরীক্ষা করা হয়নি।
- `google-services.json` সাধারণ Android client configuration; Service Account private key কখনো অ্যাপে, GitHub-এ বা চ্যাটে দেবেন না।
- Production-এর আগে Firebase App Check, rate limiting/abuse protection, server-side order validation এবং নিরাপত্তা পরীক্ষা করুন।

## Firestore Product CRUD API (নতুন)

`NativeAuth` bridge-এ এখন Admin-claim যাচাই করে পণ্য পড়া/যোগ/সম্পাদনা/মুছার native method প্রস্তুত আছে। JavaScript callback-এ JSON string আসে:

```javascript
window.onNativeProductsResult = raw => {
  const result = JSON.parse(raw);
  if (result.success) console.log('Products:', result.products);
  else console.error(result.message);
};
window.onNativeProductSaveResult = raw => {
  const result = JSON.parse(raw);
  console.log(result.success ? 'Saved: ' + result.id : result.message);
};
window.onNativeProductDeleteResult = raw => {
  const result = JSON.parse(raw);
  console.log(result.success ? 'Deleted: ' + result.id : result.message);
};

// Admin login সফল হওয়ার পর:
NativeAuth.loadProducts();
// নতুন পণ্য: documentId ফাঁকা রাখুন; সম্পাদনা: Firestore document ID দিন
NativeAuth.saveProduct('', JSON.stringify({
  name: 'Sample product', bn: 'নমুনা পণ্য', cat: 'Surgical',
  icon: '📦', price: 100, desc: 'Description', active: true
}));
NativeAuth.deleteProduct('FIRESTORE_DOCUMENT_ID');
```

এগুলো bridge-এর API উদাহরণ; বর্তমান `index.html` Admin UI-তে এখনো এই callback ও button wiring করা হয়নি। Firestore-এ `products` collection ব্যবহার হবে। `loadProducts()` সর্বোচ্চ ৩০০টি document ফেরত দেয়।

**গুরুত্বপূর্ণ:** Firestore rules-এ `products` collection-এ Admin custom claim ছাড়া read/write অনুমোদন করবেন না। Public catalogue চালুর আগে আলাদা public-safe schema/rules তৈরি করুন; private cost, supplier বা internal notes একই public product document-এ রাখবেন না।
