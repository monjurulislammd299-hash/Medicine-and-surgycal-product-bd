# Medicine & Surgical Products — Admin Panel Demo Update

এই আপডেটে Android WebView অ্যাপের ভেতরে একটি Admin Demo Dashboard যুক্ত হয়েছে।

## কী আছে
- Admin Demo খুলতে হোম পেজের নিচে `Admin demo` লিংক
- পণ্যের তালিকা দেখা
- পণ্য যোগ, সম্পাদনা ও মুছে ফেলা
- ডেমো অর্ডার দেখা
- ডেমো অর্ডারের স্ট্যাটাস পরিবর্তন
- ডেমো পণ্য ও অর্ডারের সারাংশ

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি **শুধু লোকাল ডেমো**। কোনো Admin password/login, Firebase, online database, API, role permission বা server-side security এতে নেই। অ্যাপ ব্যবহারকারীরা Admin demo লিংক দেখতে ও খুলতে পারে। তাই বাস্তব গ্রাহকের তথ্য, আসল অর্ডার বা ব্যবসার কার্যক্রম পরিচালনায় এটি ব্যবহার করবেন না।

## Package name
`com.medicinesurgical.store`

## APK Build
1. ZIP extract করুন।
2. Repository-তে আগের `app` ফোল্ডারের পরিবর্তে এই ZIP-এর `MedicineSurgicalAndroid/app` ফোল্ডার আপলোড করুন।
3. Root-এর Gradle ফাইল এবং GitHub Actions workflow আগের মতো রাখুন।
4. GitHub → Actions → Build APK → Run workflow চালান।
5. Build সফল হলে APK artifact ডাউনলোড করে ইনস্টল করুন।

## Production-এর আগে
বিশ্বস্ত backend, server-verified Admin role, Firestore/SQL security rules, audit log, input validation, prescription review এবং প্রযোজ্য DGDA/ফার্মেসি লাইসেন্সিং যাচাই প্রয়োজন। Admin privilege কখনো Android client থেকে দেওয়া যাবে না।
