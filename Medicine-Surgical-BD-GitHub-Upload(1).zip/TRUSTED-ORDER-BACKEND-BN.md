# ধাপ ২৭ — Trusted Order Backend

## কী পরিবর্তন হয়েছে
- Android bridge এখন শুধু customer details, product IDs এবং quantities পাঠায়।
- `functions/index.js`-এর `createOrder` callable Cloud Function authenticated customer যাচাই করে।
- Backend Firestore থেকে প্রতিটি পণ্যের active status ও বর্তমান price পড়ে line total এবং grand total হিসাব করে।
- Order write Admin SDK দিয়ে backend থেকে হয়; Firestore Rules-এ client-side order create নিষিদ্ধ।
- Customer নিজের `customerUid`-এর order পড়তে পারে; Admin status update করতে পারে।

## Deploy
```bash
npm install -g firebase-tools
firebase login
firebase use --add
cd functions
npm install
cd ..
firebase deploy --only functions:createOrder,firestore:rules
```

প্রথমে Firebase project-এ billing/Blaze plan ও Cloud Functions API সক্রিয় থাকতে হবে। `google-services.json` Android `app/` folder-এ দিন। Authentication → Sign-in method → Anonymous Enable রাখুন।

## পরীক্ষা
1. Active product Firestore-এ রাখুন, যার `price` number এবং `active` true।
2. App থেকে COD order দিন।
3. Firestore `orders` document-এ server-calculated `items`, `total`, `Pending` status ও `customerUid` দেখুন।
4. Client SDK দিয়ে সরাসরি `orders` create করার চেষ্টা করলে Rules deny করবে।
5. দ্বিতীয় Anonymous account দিয়ে প্রথম account-এর order query করলে কোনো order পাওয়া যাবে না।

## সীমাবদ্ধতা
- Firebase App Check এখনো enforce করা হয়নি; production-এ configure ও enforce করুন।
- Anonymous account app data clear/uninstall বা অন্য ডিভাইসে স্বয়ংক্রিয়ভাবে স্থানান্তর হয় না।
- bKash/Nagad gateway, inventory reservation, shipping fee, tax, prescription validation, pharmacist review, refunds ও audit log নেই।
- Admin custom claim শুধু trusted Admin SDK/backend দিয়ে দিন।
