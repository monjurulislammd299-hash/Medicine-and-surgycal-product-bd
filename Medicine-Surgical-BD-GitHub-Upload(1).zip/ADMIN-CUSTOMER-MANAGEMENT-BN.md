# ধাপ ৩০ — Admin Customer Management Panel

## নতুন সুবিধা
- Firebase Admin Panel-এ গ্রাহক তালিকা দেখা
- নাম, যাচাইকৃত ফোন নম্বর, UID এবং অর্ডার সংখ্যা
- নির্দিষ্ট গ্রাহকের অর্ডার ইতিহাস দেখা
- গ্রাহকের ব্যক্তিগত প্রোফাইল ও ঠিকানায় Admin read access; গ্রাহকের write access নিজ UID-তেই সীমাবদ্ধ

## Firebase Rules
এই ZIP-এর `firestore.rules` Firebase Console → Firestore Database → Rules-এ Publish করুন। Admin custom claim `admin=true` থাকা আবশ্যক।

## গুরুত্বপূর্ণ সীমা
- তালিকায় সর্বোচ্চ ৫০০টি customer profile এবং সর্বোচ্চ ১,০০০টি সাম্প্রতিক order থেকে অর্ডার সংখ্যা গণনা হয়। এটি সম্পূর্ণ lifetime analytics নয়।
- গ্রাহক প্রোফাইল না তৈরি করলে (OTP login-এর পর নাম Save না করলে) তার profile তালিকায় নাও দেখা যেতে পারে; অর্ডার রেকর্ড তবু orders collection-এ থাকে।
- Admin access শুধু Firebase Auth custom claim দিয়ে নিয়ন্ত্রিত; APK-তে secret বা service-account key রাখা হয়নি।
- Android Gradle build, Firebase Rules Emulator এবং live Firestore test এই পরিবেশে চালানো হয়নি।
