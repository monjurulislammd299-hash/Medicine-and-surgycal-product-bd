package com.medicinesurgical.store

import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.app.Activity
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.PhoneAuthCredential
import java.util.concurrent.TimeUnit
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import org.json.JSONArray
import org.json.JSONObject

/** Firebase bridge for the bundled local WebView. All write operations require an Admin custom claim. */
class FirebaseWebBridge(private val activity: Activity, private val webView: WebView) {
    private var phoneVerificationId: String? = null
    private var pendingPhoneNumber: String? = null

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()

    @JavascriptInterface
    fun signIn(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            authReply(false, false, null, null, "Email ও password দিতে হবে")
            return
        }
        auth.signInWithEmailAndPassword(email.trim(), password)
            .addOnCompleteListener { task ->
                if (!task.isSuccessful) {
                    authReply(false, false, null, null, task.exception?.localizedMessage ?: "Login ব্যর্থ")
                } else verifyAdmin { isAdmin, error ->
                    val user = auth.currentUser
                    if (isAdmin) authReply(true, true, user?.uid, user?.email, null)
                    else {
                        auth.signOut()
                        authReply(false, false, null, null, error ?: "এই অ্যাকাউন্টে Admin অনুমতি নেই")
                    }
                }
            }
    }

    @JavascriptInterface
    fun checkSession() {
        if (auth.currentUser == null) {
            authReply(false, false, null, null, "কোনো Login session নেই")
            return
        }
        verifyAdmin { isAdmin, error ->
            val user = auth.currentUser
            if (isAdmin) authReply(true, true, user?.uid, user?.email, null)
            else {
                auth.signOut()
                authReply(false, false, null, null, error ?: "Admin অনুমতি পাওয়া যায়নি")
            }
        }
    }

    @JavascriptInterface
    fun signOut() {
        auth.signOut()
        authReply(false, false, null, null, "Logout সম্পন্ন")
    }

    /** Send Firebase SMS OTP. The current anonymous UID is retained when the phone credential is linked. */
    @JavascriptInterface
    fun startPhoneOtp(phoneNumber: String) {
        val phone = phoneNumber.trim()
        if (!phone.matches(Regex("\\+[1-9][0-9]{7,14}"))) {
            callback("onNativePhoneOtpSent", JSONObject().put("success", false).put("message", "মোবাইল নম্বর +8801XXXXXXXXX ফরম্যাটে দিন"))
            return
        }
        pendingPhoneNumber = phone
        val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                completePhoneSignIn(credential)
            }
            override fun onVerificationFailed(error: com.google.firebase.FirebaseException) {
                callback("onNativePhoneOtpSent", JSONObject().put("success", false).put("message", error.localizedMessage ?: "OTP পাঠানো যায়নি"))
            }
            override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                phoneVerificationId = id
                callback("onNativePhoneOtpSent", JSONObject().put("success", true).put("message", "SMS OTP পাঠানো হয়েছে"))
            }
        }
        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phone)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(callbacks)
            .build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    @JavascriptInterface
    fun verifyPhoneOtp(code: String) {
        val id = phoneVerificationId
        if (id.isNullOrBlank() || !code.trim().matches(Regex("[0-9]{6}"))) {
            callback("onNativePhoneOtpResult", JSONObject().put("success", false).put("message", "৬ সংখ্যার OTP লিখুন"))
            return
        }
        completePhoneSignIn(PhoneAuthProvider.getCredential(id, code.trim()))
    }

    private fun completePhoneSignIn(credential: PhoneAuthCredential) {
        val current = auth.currentUser
        if (current != null && !current.isAnonymous && !current.phoneNumber.isNullOrBlank()) {
            if (current.phoneNumber == pendingPhoneNumber) {
                callback("onNativePhoneOtpResult", JSONObject().put("success", true).put("uid", current.uid).put("phone", current.phoneNumber))
            } else {
                callback("onNativePhoneOtpResult", JSONObject().put("success", false).put("message", "এই ডিভাইসে অন্য ফোন অ্যাকাউন্ট যুক্ত আছে। আগে Logout করুন।"))
            }
            return
        }
        val task = if (current != null) current.linkWithCredential(credential) else auth.signInWithCredential(credential)
        task.addOnSuccessListener { result ->
            phoneVerificationId = null
            val user = result.user ?: auth.currentUser
            callback("onNativePhoneOtpResult", JSONObject().put("success", true).put("uid", user?.uid ?: "").put("phone", user?.phoneNumber ?: ""))
        }.addOnFailureListener { error ->
            callback("onNativePhoneOtpResult", JSONObject().put("success", false).put("message", error.localizedMessage ?: "OTP যাচাই ব্যর্থ; নম্বরটি অন্য অ্যাকাউন্টে যুক্ত থাকতে পারে"))
        }
    }

    /** Save the signed-in customer's basic profile under their own UID. */
    @JavascriptInterface
    fun saveCustomerProfile(name: String) {
        val user = auth.currentUser
        if (user == null || user.isAnonymous || user.phoneNumber.isNullOrBlank()) {
            callback("onNativeCustomerProfileSaveResult", JSONObject().put("success", false).put("message", "আগে ফোন OTP দিয়ে Login করুন"))
            return
        }
        val cleanName = name.trim()
        if (cleanName.isBlank() || cleanName.length > 100) {
            callback("onNativeCustomerProfileSaveResult", JSONObject().put("success", false).put("message", "নাম ১ থেকে ১০০ অক্ষরের মধ্যে দিন"))
            return
        }
        val data = hashMapOf<String, Any>("name" to cleanName, "phone" to (user.phoneNumber ?: ""), "updatedAt" to FieldValue.serverTimestamp())
        db.collection("customerProfiles").document(user.uid).set(data, com.google.firebase.firestore.SetOptions.merge())
            .addOnSuccessListener { callback("onNativeCustomerProfileSaveResult", JSONObject().put("success", true)) }
            .addOnFailureListener { err -> callback("onNativeCustomerProfileSaveResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "প্রোফাইল সংরক্ষণ হয়নি")) }
    }

    @JavascriptInterface
    fun loadCustomerProfile() {
        val user = auth.currentUser
        if (user == null || user.isAnonymous || user.phoneNumber.isNullOrBlank()) {
            callback("onNativeCustomerProfileResult", JSONObject().put("success", false).put("message", "আগে ফোন OTP দিয়ে Login করুন"))
            return
        }
        db.collection("customerProfiles").document(user.uid).get()
            .addOnSuccessListener { snap ->
                val row = JSONObject(snap.data ?: emptyMap<String, Any>())
                row.put("phone", user.phoneNumber)
                callback("onNativeCustomerProfileResult", JSONObject().put("success", true).put("profile", row))
            }
            .addOnFailureListener { err -> callback("onNativeCustomerProfileResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "প্রোফাইল লোড হয়নি")) }
    }

    @JavascriptInterface
    fun loadSavedAddresses() {
        val user = auth.currentUser
        if (user == null || user.isAnonymous || user.phoneNumber.isNullOrBlank()) {
            callback("onNativeSavedAddressesResult", JSONObject().put("success", false).put("message", "আগে ফোন OTP দিয়ে Login করুন"))
            return
        }
        db.collection("customerProfiles").document(user.uid).collection("addresses").limit(30).get()
            .addOnSuccessListener { snapshot ->
                val rows = JSONArray()
                snapshot.documents.forEach { doc ->
                    val row = JSONObject(doc.data ?: emptyMap<String, Any>())
                    row.put("id", doc.id)
                    rows.put(row)
                }
                callback("onNativeSavedAddressesResult", JSONObject().put("success", true).put("addresses", rows))
            }
            .addOnFailureListener { err -> callback("onNativeSavedAddressesResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "ঠিকানা লোড হয়নি")) }
    }

    @JavascriptInterface
    fun saveAddress(addressJson: String) {
        val user = auth.currentUser
        if (user == null || user.isAnonymous || user.phoneNumber.isNullOrBlank()) {
            callback("onNativeSaveAddressResult", JSONObject().put("success", false).put("message", "আগে ফোন OTP দিয়ে Login করুন"))
            return
        }
        try {
            val input = JSONObject(addressJson)
            val label = input.optString("label", "বাড়ি").trim().take(30)
            val address = input.optString("address").trim()
            val recipient = input.optString("recipient", "").trim().take(100)
            val phone = input.optString("phone", user.phoneNumber ?: "").trim()
            if (address.isBlank() || address.length > 500 || phone.length !in 10..16) {
                callback("onNativeSaveAddressResult", JSONObject().put("success", false).put("message", "ঠিকানা ও সঠিক মোবাইল নম্বর দিন"))
                return
            }
            val data = hashMapOf<String, Any>("label" to if (label.isBlank()) "বাড়ি" else label, "address" to address, "recipient" to recipient, "phone" to phone, "createdAt" to FieldValue.serverTimestamp())
            db.collection("customerProfiles").document(user.uid).collection("addresses").add(data)
                .addOnSuccessListener { ref -> callback("onNativeSaveAddressResult", JSONObject().put("success", true).put("id", ref.id)) }
                .addOnFailureListener { err -> callback("onNativeSaveAddressResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "ঠিকানা সংরক্ষণ হয়নি")) }
        } catch (err: Exception) {
            callback("onNativeSaveAddressResult", JSONObject().put("success", false).put("message", "ঠিকানার তথ্য সঠিক নয়"))
        }
    }

    @JavascriptInterface
    fun deleteSavedAddress(addressId: String) {
        val user = auth.currentUser
        if (user == null || user.isAnonymous || user.phoneNumber.isNullOrBlank() || addressId.isBlank()) {
            callback("onNativeDeleteAddressResult", JSONObject().put("success", false).put("message", "Login বা ঠিকানার তথ্য সঠিক নয়"))
            return
        }
        db.collection("customerProfiles").document(user.uid).collection("addresses").document(addressId).delete()
            .addOnSuccessListener { callback("onNativeDeleteAddressResult", JSONObject().put("success", true).put("id", addressId)) }
            .addOnFailureListener { err -> callback("onNativeDeleteAddressResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "ঠিকানা মুছতে পারেনি")) }
    }

    /** Returns only active, public-safe catalogue fields. Firestore rules restrict this query to active products. */
    @JavascriptInterface
    fun loadPublicProducts() {
        db.collection("products").whereEqualTo("active", true).limit(300).get()
            .addOnSuccessListener { snapshot ->
                val rows = JSONArray()
                snapshot.documents.forEach { doc ->
                    val item = JSONObject(doc.data ?: emptyMap<String, Any>())
                    item.put("id", doc.id)
                    rows.put(item)
                }
                callback("onNativePublicProductsResult", JSONObject().put("success", true).put("products", rows))
            }
            .addOnFailureListener { err ->
                callback("onNativePublicProductsResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "পণ্য লোড ব্যর্থ"))
            }
    }

    /** Returns all product documents to an authenticated Admin. */
    @JavascriptInterface
    fun loadProducts() {
        requireAdmin("onNativeProductsResult") { allowed ->
            if (!allowed) return@requireAdmin
            db.collection("products").limit(300).get()
                .addOnSuccessListener { snapshot ->
                    val rows = JSONArray()
                    snapshot.documents.forEach { doc ->
                        val item = JSONObject(doc.data ?: emptyMap<String, Any>())
                        item.put("id", doc.id)
                        rows.put(item)
                    }
                    callback("onNativeProductsResult", JSONObject().put("success", true).put("products", rows))
                }
                .addOnFailureListener { err ->
                    callback("onNativeProductsResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "পণ্য লোড ব্যর্থ"))
                }
        }
    }

    /** Save or update a product. Pass an empty documentId to create a new product. */
    @JavascriptInterface
    fun saveProduct(documentId: String, productJson: String) {
        requireAdmin("onNativeProductSaveResult") { allowed ->
            if (!allowed) return@requireAdmin
            try {
                val input = JSONObject(productJson)
                val name = input.optString("name").trim()
                val category = input.optString("cat").trim()
                val price = input.optDouble("price", -1.0)
                if (name.isBlank() || category.isBlank() || price < 0 || price.isNaN() || price.isInfinite()) {
                    callback("onNativeProductSaveResult", JSONObject().put("success", false).put("message", "নাম, ক্যাটাগরি ও সঠিক মূল্য দিন"))
                    return@requireAdmin
                }
                val data = hashMapOf<String, Any>(
                    "name" to name,
                    "bn" to input.optString("bn"),
                    "cat" to category,
                    "icon" to input.optString("icon", "📦"),
                    "price" to price,
                    "desc" to input.optString("desc"),
                    "active" to input.optBoolean("active", true),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                val ref = if (documentId.isBlank()) db.collection("products").document()
                          else db.collection("products").document(documentId)
                ref.set(data, com.google.firebase.firestore.SetOptions.merge())
                    .addOnSuccessListener { callback("onNativeProductSaveResult", JSONObject().put("success", true).put("id", ref.id)) }
                    .addOnFailureListener { err -> callback("onNativeProductSaveResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "সংরক্ষণ ব্যর্থ")) }
            } catch (err: Exception) {
                callback("onNativeProductSaveResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "পণ্যের তথ্য সঠিক নয়"))
            }
        }
    }

    @JavascriptInterface
    fun deleteProduct(documentId: String) {
        requireAdmin("onNativeProductDeleteResult") { allowed ->
            if (!allowed) return@requireAdmin
            if (documentId.isBlank()) {
                callback("onNativeProductDeleteResult", JSONObject().put("success", false).put("message", "Product ID পাওয়া যায়নি"))
                return@requireAdmin
            }
            db.collection("products").document(documentId).delete()
                .addOnSuccessListener { callback("onNativeProductDeleteResult", JSONObject().put("success", true).put("id", documentId)) }
                .addOnFailureListener { err -> callback("onNativeProductDeleteResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "মুছতে ব্যর্থ")) }
        }
    }


    /** Submit cart IDs and quantities to a trusted Cloud Function; client never sets prices or totals. */
    @JavascriptInterface
    fun submitOrder(orderJson: String) {
        try {
            val input = JSONObject(orderJson)
            val customer = input.optString("customer").trim()
            val phone = input.optString("phone").trim()
            val address = input.optString("address").trim()
            val payment = input.optString("payment", "Cash on Delivery")
            val requested = input.optJSONArray("items") ?: JSONArray()
            if (customer.isBlank() || phone.length !in 10..16 || address.isBlank() || requested.length() == 0 || payment != "Cash on Delivery") {
                callback("onNativeOrderSubmitResult", JSONObject().put("success", false).put("message", "নাম, সঠিক মোবাইল, ঠিকানা, পণ্য ও Cash on Delivery নির্বাচন করুন"))
                return
            }
            val cartItems = (0 until requested.length()).map { i ->
                val row = requested.getJSONObject(i)
                val id = row.optString("id").trim()
                val qty = row.optInt("qty", 0)
                require(id.isNotBlank() && qty in 1..50) { "কার্টের পণ্যের তথ্য সঠিক নয়" }
                mapOf("productId" to id, "qty" to qty)
            }
            val continueWithUser: () -> Unit = {
                val data = hashMapOf<String, Any>(
                    "customer" to customer, "phone" to phone, "address" to address,
                    "payment" to payment, "items" to cartItems
                )
                com.google.firebase.functions.FirebaseFunctions.getInstance("asia-south1")
                    .getHttpsCallable("createOrder").call(data)
                    .addOnSuccessListener { result ->
                        val response = result.data as? Map<*, *>
                        callback("onNativeOrderSubmitResult", JSONObject()
                            .put("success", true)
                            .put("orderId", response?.get("orderId")?.toString() ?: "")
                            .put("total", response?.get("total") ?: 0))
                    }
                    .addOnFailureListener { err ->
                        callback("onNativeOrderSubmitResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "অর্ডার জমা হয়নি"))
                    }
            }
            if (auth.currentUser == null) {
                auth.signInAnonymously().addOnSuccessListener { continueWithUser() }
                    .addOnFailureListener { err -> callback("onNativeOrderSubmitResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "Customer session তৈরি হয়নি")) }
            } else continueWithUser()
        } catch (err: Exception) {
            callback("onNativeOrderSubmitResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "অর্ডার তথ্য সঠিক নয়"))
        }
    }

    /** Load only orders belonging to the persistent anonymous customer identity. */
    @JavascriptInterface
    fun loadMyOrders() {
        val current = auth.currentUser
        val task = if (current == null) auth.signInAnonymously() else null
        val load: () -> Unit = {
            val user = auth.currentUser
            if (user == null) {
                callback("onNativeMyOrdersResult", JSONObject().put("success", false).put("message", "Customer session তৈরি হয়নি"))
            } else {
                db.collection("orders").whereEqualTo("customerUid", user.uid).limit(100).get()
                    .addOnSuccessListener { snapshot ->
                        val rows = JSONArray()
                        snapshot.documents.sortedByDescending { it.getTimestamp("createdAt")?.toDate()?.time ?: 0L }.forEach { doc ->
                            val row = JSONObject(doc.data ?: emptyMap<String, Any>())
                            row.put("id", doc.id)
                            rows.put(row)
                        }
                        callback("onNativeMyOrdersResult", JSONObject().put("success", true).put("orders", rows))
                    }
                    .addOnFailureListener { err -> callback("onNativeMyOrdersResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "অর্ডার লোড ব্যর্থ")) }
            }
        }
        if (task == null) load() else task.addOnSuccessListener { load() }
            .addOnFailureListener { err -> callback("onNativeMyOrdersResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "Customer session তৈরি হয়নি")) }
    }

    @JavascriptInterface
    /** Submit a seller application; requires a verified phone-authenticated customer. */
    @JavascriptInterface
    fun submitSellerApplication(business: String, contactName: String, licenseInfo: String, details: String) {
        val user = auth.currentUser
        val phone = user?.phoneNumber ?: ""
        if (user == null || user.isAnonymous || phone.isBlank()) {
            callback("onNativeSellerSubmitResult", JSONObject().put("success", false).put("message", "বিক্রেতা আবেদন করতে Phone OTP Login করুন"))
            return
        }
        val cleanBusiness = business.trim()
        val cleanName = contactName.trim()
        val cleanLicense = licenseInfo.trim()
        val cleanDetails = details.trim()
        if (cleanBusiness.length !in 2..120 || cleanName.length !in 2..100 || cleanLicense.length !in 3..1000 || cleanDetails.length > 1000) {
            callback("onNativeSellerSubmitResult", JSONObject().put("success", false).put("message", "ব্যবসা, যোগাযোগের নাম ও লাইসেন্সের তথ্য সঠিকভাবে দিন"))
            return
        }
        val data = hashMapOf<String, Any>(
            "uid" to user.uid, "business" to cleanBusiness, "contactName" to cleanName,
            "phone" to phone, "licenseInfo" to cleanLicense, "details" to cleanDetails,
            "status" to "Pending", "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        db.collection("sellerApplications").whereEqualTo("uid", user.uid).whereEqualTo("status", "Pending").limit(1).get()
            .addOnSuccessListener { existing ->
                if (!existing.isEmpty) {
                    callback("onNativeSellerSubmitResult", JSONObject().put("success", false).put("message", "আপনার একটি আবেদন ইতোমধ্যে পর্যালোচনায় আছে"))
                } else db.collection("sellerApplications").add(data)
                    .addOnSuccessListener { ref -> callback("onNativeSellerSubmitResult", JSONObject().put("success", true).put("applicationId", ref.id)) }
                    .addOnFailureListener { err -> callback("onNativeSellerSubmitResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "আবেদন জমা হয়নি")) }
            }
            .addOnFailureListener { err -> callback("onNativeSellerSubmitResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "আবেদন যাচাই করা যায়নি")) }
    }

    /** Admin-only seller application queue. */
    @JavascriptInterface
    fun loadSellerApplications() {
        requireAdmin("onNativeSellerApplicationsResult") { allowed ->
            if (!allowed) return@requireAdmin
            db.collection("sellerApplications").orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(300).get()
                .addOnSuccessListener { snapshot ->
                    val rows = JSONArray()
                    snapshot.documents.forEach { doc ->
                        val row = JSONObject().put("id", doc.id)
                        doc.data?.forEach { (key, value) -> row.put(key, value ?: JSONObject.NULL) }
                        rows.put(row)
                    }
                    callback("onNativeSellerApplicationsResult", JSONObject().put("success", true).put("applications", rows))
                }
                .addOnFailureListener { err -> callback("onNativeSellerApplicationsResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "বিক্রেতার আবেদন লোড হয়নি")) }
        }
    }

    /** Admin-only decision; approval is a seller application status, not an automatic licence verification. */
    @JavascriptInterface
    fun reviewSellerApplication(applicationId: String, status: String, adminNote: String) {
        requireAdmin("onNativeSellerReviewResult") { allowed ->
            if (!allowed) return@requireAdmin
            val note = adminNote.trim().take(500)
            if (applicationId.isBlank() || applicationId.length > 128 || status !in setOf("Approved", "Rejected", "Pending")) {
                callback("onNativeSellerReviewResult", JSONObject().put("success", false).put("message", "আবেদন বা সিদ্ধান্ত সঠিক নয়"))
                return@requireAdmin
            }
            val appRef = db.collection("sellerApplications").document(applicationId)
            appRef.get().addOnSuccessListener { app ->
                if (!app.exists()) { callback("onNativeSellerReviewResult", JSONObject().put("success", false).put("message", "আবেদন পাওয়া যায়নি")); return@addOnSuccessListener }
                val uid = app.getString("uid") ?: ""
                val batch = db.batch()
                batch.update(appRef, mapOf("status" to status, "adminNote" to note, "reviewedBy" to (auth.currentUser?.uid ?: ""), "updatedAt" to FieldValue.serverTimestamp()))
                if (uid.isNotBlank()) batch.set(db.collection("sellerAccounts").document(uid), mapOf("uid" to uid, "applicationId" to applicationId, "business" to (app.getString("business") ?: ""), "status" to status, "updatedAt" to FieldValue.serverTimestamp()))
                batch.commit().addOnSuccessListener { callback("onNativeSellerReviewResult", JSONObject().put("success", true).put("id", applicationId)) }
                    .addOnFailureListener { err -> callback("onNativeSellerReviewResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "সিদ্ধান্ত সংরক্ষণ হয়নি")) }
            }.addOnFailureListener { err -> callback("onNativeSellerReviewResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "আবেদন যাচাই হয়নি")) }
        }
    }

    /** Seller dashboard: read own application and seller product submissions. */
    @JavascriptInterface
    fun loadSellerDashboard() {
        val user = auth.currentUser
        if (user == null || user.isAnonymous || user.phoneNumber.isNullOrBlank()) {
            callback("onNativeSellerDashboardResult", JSONObject().put("success", false).put("message", "Seller Dashboard দেখতে Phone OTP Login করুন"))
            return
        }
        db.collection("sellerApplications").whereEqualTo("uid", user.uid).limit(10).get()
            .addOnSuccessListener { apps ->
                val appRows = JSONArray()
                apps.documents.forEach { doc ->
                    val row = JSONObject().put("id", doc.id)
                    doc.data?.forEach { (key, value) -> row.put(key, value ?: JSONObject.NULL) }
                    appRows.put(row)
                }
                db.collection("sellerProducts").whereEqualTo("sellerUid", user.uid).limit(100).get()
                    .addOnSuccessListener { products ->
                        val productRows = JSONArray()
                        products.documents.forEach { doc ->
                            val row = JSONObject().put("id", doc.id)
                            doc.data?.forEach { (key, value) -> row.put(key, value ?: JSONObject.NULL) }
                            productRows.put(row)
                        }
                        callback("onNativeSellerDashboardResult", JSONObject().put("success", true).put("applications", appRows).put("products", productRows).put("phone", user.phoneNumber))
                    }
                    .addOnFailureListener { err -> callback("onNativeSellerDashboardResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "পণ্যের তালিকা লোড হয়নি")) }
            }
            .addOnFailureListener { err -> callback("onNativeSellerDashboardResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "বিক্রেতার তথ্য লোড হয়নি")) }
    }

    /** Seller product submissions are private until separately reviewed by Admin. */
    @JavascriptInterface
    fun submitSellerProduct(name: String, category: String, price: Double, stock: Long, description: String) {
        val user = auth.currentUser
        if (user == null || user.isAnonymous || user.phoneNumber.isNullOrBlank()) {
            callback("onNativeSellerProductSubmitResult", JSONObject().put("success", false).put("message", "Phone OTP Login প্রয়োজন"))
            return
        }
        val cleanName = name.trim(); val cleanCategory = category.trim(); val cleanDescription = description.trim()
        if (cleanName.length !in 2..120 || cleanCategory.length !in 2..60 || !price.isFinite() || price <= 0.0 || price > 10000000.0 || stock !in 0..1000000 || cleanDescription.length > 1000) {
            callback("onNativeSellerProductSubmitResult", JSONObject().put("success", false).put("message", "পণ্যের নাম, ক্যাটাগরি, মূল্য ও স্টক সঠিকভাবে দিন")); return
        }
        val data = hashMapOf<String, Any>("sellerUid" to user.uid, "sellerPhone" to user.phoneNumber!!, "name" to cleanName, "category" to cleanCategory, "price" to price, "stock" to stock, "description" to cleanDescription, "status" to "Pending", "createdAt" to FieldValue.serverTimestamp(), "updatedAt" to FieldValue.serverTimestamp())
        db.collection("sellerProducts").add(data)
            .addOnSuccessListener { ref -> callback("onNativeSellerProductSubmitResult", JSONObject().put("success", true).put("id", ref.id)) }
            .addOnFailureListener { err -> callback("onNativeSellerProductSubmitResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "পণ্য জমা হয়নি")) }
    }

    /** Admin-only seller product moderation queue. */
    @JavascriptInterface
    fun loadSellerProductsForAdmin() {
        requireAdmin("onNativeSellerProductsAdminResult") { allowed ->
            if (!allowed) return@requireAdmin
            db.collection("sellerProducts").orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(300).get()
                .addOnSuccessListener { snap ->
                    val rows = JSONArray(); snap.documents.forEach { doc -> val row = JSONObject().put("id", doc.id); doc.data?.forEach { (k,v) -> row.put(k, v ?: JSONObject.NULL) }; rows.put(row) }
                    callback("onNativeSellerProductsAdminResult", JSONObject().put("success", true).put("products", rows))
                }
                .addOnFailureListener { err -> callback("onNativeSellerProductsAdminResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "বিক্রেতার পণ্য লোড হয়নি")) }
        }
    }

    @JavascriptInterface
    fun reviewSellerProduct(productId: String, status: String, adminNote: String) {
        requireAdmin("onNativeSellerProductReviewResult") { allowed ->
            if (!allowed) return@requireAdmin
            if (productId.isBlank() || productId.length > 128 || status !in setOf("Approved", "Rejected", "Pending")) {
                callback("onNativeSellerProductReviewResult", JSONObject().put("success", false).put("message", "পণ্য বা সিদ্ধান্ত সঠিক নয়")); return@requireAdmin
            }
            db.collection("sellerProducts").document(productId).update(mapOf("status" to status, "adminNote" to adminNote.trim().take(500), "reviewedBy" to (auth.currentUser?.uid ?: ""), "updatedAt" to FieldValue.serverTimestamp()))
                .addOnSuccessListener { callback("onNativeSellerProductReviewResult", JSONObject().put("success", true).put("id", productId)) }
                .addOnFailureListener { err -> callback("onNativeSellerProductReviewResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "সিদ্ধান্ত সংরক্ষণ হয়নি")) }
        }
    }

    /** Admin-only customer directory with order counts derived from recent order records. */
    @JavascriptInterface
    fun loadCustomers() {
        requireAdmin("onNativeCustomersResult") { allowed ->
            if (!allowed) return@requireAdmin
            db.collection("customerProfiles").limit(500).get()
                .addOnSuccessListener { profiles ->
                    db.collection("orders").orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(1000).get()
                        .addOnSuccessListener { orderSnapshot ->
                            val counts = mutableMapOf<String, Int>()
                            orderSnapshot.documents.forEach { order ->
                                val uid = order.getString("customerUid") ?: ""
                                if (uid.isNotBlank()) counts[uid] = (counts[uid] ?: 0) + 1
                            }
                            val rows = JSONArray()
                            profiles.documents.forEach { doc ->
                                val row = JSONObject()
                                    .put("uid", doc.id)
                                    .put("name", doc.getString("name") ?: "")
                                    .put("phone", doc.getString("phone") ?: "")
                                    .put("orderCount", counts[doc.id] ?: 0)
                                val updated = doc.getTimestamp("updatedAt")
                                if (updated != null) row.put("updatedAt", updated.toDate().time)
                                rows.put(row)
                            }
                            callback("onNativeCustomersResult", JSONObject().put("success", true).put("customers", rows))
                        }
                        .addOnFailureListener { err -> callback("onNativeCustomersResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "অর্ডার গণনা করা যায়নি")) }
                }
                .addOnFailureListener { err -> callback("onNativeCustomersResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "গ্রাহক তালিকা লোড হয়নি")) }
        }
    }

    /** Admin-only order history for a selected customer UID. */
    @JavascriptInterface
    fun loadCustomerOrders(customerUid: String) {
        requireAdmin("onNativeCustomerOrdersResult") { allowed ->
            if (!allowed) return@requireAdmin
            if (customerUid.isBlank() || customerUid.length > 128) {
                callback("onNativeCustomerOrdersResult", JSONObject().put("success", false).put("message", "গ্রাহক ID সঠিক নয়"))
                return@requireAdmin
            }
            db.collection("orders").whereEqualTo("customerUid", customerUid).limit(100).get()
                .addOnSuccessListener { snapshot ->
                    val rows = JSONArray()
                    snapshot.documents.forEach { doc ->
                        val data = doc.data ?: emptyMap<String, Any>()
                        val row = JSONObject().put("id", doc.id)
                        listOf("customer", "phone", "address", "payment", "status", "total").forEach { key ->
                            val value = data[key]
                            if (value != null) row.put(key, value)
                        }
                        rows.put(row)
                    }
                    callback("onNativeCustomerOrdersResult", JSONObject().put("success", true).put("orders", rows))
                }
                .addOnFailureListener { err -> callback("onNativeCustomerOrdersResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "গ্রাহকের অর্ডার লোড হয়নি")) }
        }
    }

    fun loadOrders() {
        requireAdmin("onNativeOrdersResult") { allowed ->
            if (!allowed) return@requireAdmin
            db.collection("orders").orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(200).get()
                .addOnSuccessListener { snapshot ->
                    val rows = JSONArray()
                    snapshot.documents.forEach { doc ->
                        val row = JSONObject()
                        row.put("id", doc.id)
                        doc.data?.forEach { (key, value) -> row.put(key, value?.toString() ?: "") }
                        rows.put(row)
                    }
                    callback("onNativeOrdersResult", JSONObject().put("success", true).put("orders", rows))
                }
                .addOnFailureListener { err -> callback("onNativeOrdersResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "অর্ডার লোড ব্যর্থ")) }
        }
    }

    @JavascriptInterface
    fun updateOrderStatus(orderId: String, status: String) {
        requireAdmin("onNativeOrderStatusResult") { allowed ->
            if (!allowed) return@requireAdmin
            val valid = setOf("Pending", "Confirmed", "Shipped", "Delivered", "Cancelled")
            if (orderId.isBlank() || status !in valid) {
                callback("onNativeOrderStatusResult", JSONObject().put("success", false).put("message", "অর্ডার বা স্ট্যাটাস সঠিক নয়"))
                return@requireAdmin
            }
            db.collection("orders").document(orderId).update(mapOf("status" to status, "updatedAt" to FieldValue.serverTimestamp()))
                .addOnSuccessListener { callback("onNativeOrderStatusResult", JSONObject().put("success", true).put("id", orderId)) }
                .addOnFailureListener { err -> callback("onNativeOrderStatusResult", JSONObject().put("success", false).put("message", err.localizedMessage ?: "স্ট্যাটাস আপডেট ব্যর্থ")) }
        }
    }

    private fun requireAdmin(callbackName: String, action: (Boolean) -> Unit) {
        verifyAdmin { allowed, error ->
            if (!allowed) {
                callback(callbackName, JSONObject().put("success", false).put("message", error ?: "Admin অনুমতি প্রয়োজন"))
            }
            action(allowed)
        }
    }

    private fun verifyAdmin(done: (Boolean, String?) -> Unit) {
        val user = auth.currentUser
        if (user == null) {
            done(false, "আগে Admin Login করুন")
            return
        }
        user.getIdToken(true).addOnSuccessListener { token ->
            done(token.claims["admin"] == true, null)
        }.addOnFailureListener { err ->
            done(false, err.localizedMessage ?: "Admin যাচাই করা যায়নি")
        }
    }

    private fun callback(name: String, payload: JSONObject) {
        webView.post {
            webView.evaluateJavascript("window.$name && window.$name(${JSONObject.quote(payload.toString())})", null)
        }
    }

    private fun authReply(success: Boolean, admin: Boolean, uid: String?, email: String?, message: String?) {
        val payload = JSONObject().apply {
            put("success", success)
            put("admin", admin)
            put("uid", uid ?: JSONObject.NULL)
            put("email", email ?: JSONObject.NULL)
            put("message", message ?: "Login সফল")
        }
        callback("onNativeAuthResult", payload)
    }
}
