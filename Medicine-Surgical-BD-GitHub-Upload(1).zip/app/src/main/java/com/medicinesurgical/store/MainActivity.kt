package com.medicinesurgical.store

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showSplash()
        handler.postDelayed({
            if (!isFinishing) showStore(savedInstanceState)
        }, 1400)
    }

    private fun showSplash() {
        window.statusBarColor = Color.rgb(7, 93, 87)
        window.navigationBarColor = Color.rgb(16, 43, 50)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(7, 93, 87), Color.rgb(8, 127, 115)))
        }
        val logo = ImageView(this).apply {
            try { setImageDrawable(android.graphics.drawable.Drawable.createFromStream(assets.open("app-logo.png"), null)) } catch (_: Exception) {}
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Medicine & Surgical Products logo"
        }
        root.addView(logo, LinearLayout.LayoutParams(190, 190))
        val title = TextView(this).apply {
            text = "Medicine & Surgical Products"
            setTextColor(Color.WHITE)
            textSize = 21f
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 22, 0, 8)
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "আপনার বিশ্বস্ত স্বাস্থ্যসেবা পণ্য"
            setTextColor(Color.rgb(220, 245, 240))
            textSize = 14f
            gravity = Gravity.CENTER
        }
        root.addView(subtitle)
        setContentView(root)
    }

    @Suppress("SetJavaScriptEnabled")
    private fun showStore(savedInstanceState: Bundle?) {
        webView = WebView(this)
        webView.visibility = View.VISIBLE
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                // Keep navigation inside the bundled app. External pages are not loaded
                // into a WebView that has a JavaScript interface attached.
                return !url.startsWith("file:///android_asset/") && url != "about:blank"
            }
        }
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(FirebaseWebBridge(this, webView), "NativeAuth")
        setContentView(webView)
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (::webView.isInitialized) webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
