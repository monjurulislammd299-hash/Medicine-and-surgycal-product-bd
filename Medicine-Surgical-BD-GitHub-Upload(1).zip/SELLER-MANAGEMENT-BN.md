# ধাপ ৩১ — Seller Management Panel

## নতুন সুবিধা
- ফোন OTP দিয়ে authenticated গ্রাহক বিক্রেতা আবেদন জমা দিতে পারবেন।
- ব্যবসার নাম, যোগাযোগের নাম, Firebase-verified ফোন নম্বর, লাইসেন্স/অনুমোদনের বিবরণ ও অতিরিক্ত তথ্য `sellerApplications` collection-এ থাকবে।
- একই UID-এর Pending আবেদন থাকলে নতুন Pending আবেদন জমা নেওয়া হবে না।
- Admin custom claim (`admin=true`) ছাড়া আবেদন তালিকা দেখা বা সিদ্ধান্ত পরিবর্তন করা যাবে না।
- Admin আবেদন `Approved`, `Rejected` বা `Pending` করতে পারবেন এবং ঐচ্ছিক মন্তব্য যোগ করতে পারবেন।

## Firebase সেটআপ
1. `firestore.rules` সম্পূর্ণ Publish করুন।
2. Authentication → Phone provider সক্রিয় রাখুন। আবেদনকারীর ফোন নম্বর Firebase Phone Auth দিয়ে যাচাই হতে হবে।
3. Admin account-এ trusted server/Admin SDK দিয়ে `admin=true` custom claim থাকতে হবে। APK বা GitHub-এ service-account key রাখবেন না।
4. Android project-এর `app` ফোল্ডার আপডেট করে Gradle Sync ও APK Build করুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এই ফিচার আবেদন ও Admin review পরিচালনা করে; এটি সরকারি লাইসেন্স যাচাইয়ের বিকল্প নয়।
- `Approved` মানে শুধু Admin-এর আবেদন-সিদ্ধান্ত। লাইসেন্স, DGDA অনুমোদন, ফার্মেসি নিবন্ধন ও পণ্যভিত্তিক আইনগত যোগ্যতা আলাদাভাবে যাচাই করতে হবে।
- লাইসেন্সের নথি আপলোড/OCR, বিক্রেতার আলাদা পোর্টাল, পেমেন্ট/কমিশন এবং audit log এখনো যুক্ত হয়নি।
- Firestore-এ লাইসেন্স-সংক্রান্ত তথ্য ব্যক্তিগত ব্যবসায়িক তথ্য হিসেবে বিবেচনা করুন; প্রয়োজনীয় Admin-দের মধ্যেই অ্যাক্সেস সীমাবদ্ধ রাখুন।
- বাস্তব Firebase/Rules Emulator ও Android Build পরীক্ষা না করে Production-এ চালু করবেন না।
