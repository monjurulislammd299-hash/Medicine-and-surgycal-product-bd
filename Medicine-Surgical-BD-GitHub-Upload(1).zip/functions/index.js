const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');

initializeApp();
const db = getFirestore();

exports.createOrder = onCall({ region: 'asia-south1', enforceAppCheck: false }, async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'অর্ডার করতে Customer session প্রয়োজন।');

  const data = request.data || {};
  const customer = String(data.customer || '').trim();
  const phone = String(data.phone || '').trim();
  const address = String(data.address || '').trim();
  const payment = String(data.payment || '');
  const inputItems = Array.isArray(data.items) ? data.items : [];

  if (!customer || customer.length > 100 || !/^[-+0-9 ]{10,16}$/.test(phone) || !address || address.length > 500) {
    throw new HttpsError('invalid-argument', 'নাম, সঠিক মোবাইল নম্বর ও ঠিকানা দিন।');
  }
  if (payment !== 'Cash on Delivery') {
    throw new HttpsError('failed-precondition', 'বর্তমানে শুধু Cash on Delivery চালু আছে।');
  }
  if (!inputItems.length || inputItems.length > 30) {
    throw new HttpsError('invalid-argument', 'কার্টে ১ থেকে ৩০টি পণ্য থাকতে হবে।');
  }

  // Merge duplicate product IDs and validate all quantities before reading prices.
  const quantities = new Map();
  for (const item of inputItems) {
    const id = String(item.productId || '').trim();
    const qty = Number(item.qty);
    if (!id || !Number.isInteger(qty) || qty < 1 || qty > 50) {
      throw new HttpsError('invalid-argument', 'কার্টের পণ্যের তথ্য সঠিক নয়।');
    }
    quantities.set(id, (quantities.get(id) || 0) + qty);
    if (quantities.get(id) > 50) throw new HttpsError('invalid-argument', 'একটি পণ্যের সর্বোচ্চ পরিমাণ ৫০।');
  }

  const items = [];
  let total = 0;
  for (const [productId, qty] of quantities.entries()) {
    const snap = await db.collection('products').doc(productId).get();
    if (!snap.exists || snap.get('active') !== true) {
      throw new HttpsError('failed-precondition', 'কার্টের একটি পণ্য বর্তমানে পাওয়া যাচ্ছে না।');
    }
    const product = snap.data();
    const price = Number(product.price);
    if (!Number.isFinite(price) || price < 0 || price > 100000000) {
      throw new HttpsError('failed-precondition', 'একটি পণ্যের মূল্য যাচাই করা যায়নি।');
    }
    const lineTotal = Math.round((price * qty + Number.EPSILON) * 100) / 100;
    total = Math.round((total + lineTotal + Number.EPSILON) * 100) / 100;
    items.push({ productId, name: String(product.name || 'Product'), bn: String(product.bn || ''), price, qty, lineTotal });
  }

  const order = {
    customerUid: request.auth.uid,
    customer, phone, address, payment,
    items, total, status: 'Pending',
    createdAt: FieldValue.serverTimestamp()
  };
  const ref = await db.collection('orders').add(order);
  return { orderId: ref.id, total };
});
