# Medicine & Surgical Products — Android APK project

এটি Android Studio-তে খোলার জন্য একটি native Android wrapper project। আপনার ওয়েব অ্যাপ `app/src/main/assets/index.html` থেকে WebView-তে চলে; প্রাথমিক ক্যাটালগ/কার্ট ডেমো অফলাইনে খোলা যাবে।

## APK তৈরি করার নিয়ম
1. কম্পিউটারে Android Studio (stable) ইনস্টল করুন।
2. ZIP Extract করে `MedicineSurgicalAndroid` ফোল্ডারটি Android Studio-তে **Open** করুন।
3. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন এবং Android SDK Platform 35 ইনস্টল করতে বললে ইনস্টল করুন।
4. মেনু থেকে **Build → Build Bundle(s) / APK(s) → Build APK(s)** চাপুন।
5. সফল হলে `app/build/outputs/apk/debug/app-debug.apk` ফাইল পাবেন।
6. APK ফোনে পাঠিয়ে খুলুন। Android চাইলে Settings থেকে ওই ফাইল ম্যানেজার/ব্রাউজারের **Install unknown apps** অনুমতি দিন, তারপর Install চাপুন।

## সীমাবদ্ধতা
- এই পরিবেশে Android SDK/Gradle build tool নেই, তাই এখানে সরাসরি signed APK compile করা যায়নি। এই ZIP হলো APK বানানোর Android Studio source project।
- এটি debug APK তৈরির জন্য। Play Store বা public distribution-এর জন্য release signing, privacy policy, backend, secure authentication এবং testing দরকার।
- অর্ডার/পণ্য এখনো browser local storage-এ ডেমো হিসেবে থাকে; অন্য ফোনে sync হয় না। বাস্তব bKash/Nagad payment, server, delivery tracking এবং secure admin panel যুক্ত হয়নি।
- ওষুধ বিক্রির আগে বাংলাদেশে প্রযোজ্য DGDA/ফার্মেসি লাইসেন্স, prescription verification ও pharmacist oversight নিশ্চিত করতে হবে।


## ধাপ ২৫ — Firebase Customer Order ও Admin Order Management

1. Firebase Console → Authentication → Sign-in method থেকে **Anonymous** provider Enable করুন (গ্রাহক অর্ডার জমার জন্য)।
2. Firestore Database → Rules-এ এই ZIP-এর `firestore.rules` প্রকাশ করুন।
3. `app/src/main/java/.../FirebaseWebBridge.kt` এবং `app/src/main/assets/index.html` আপডেট করুন।
4. GitHub Actions থেকে APK build করুন।
5. Admin account-এ Firebase Auth এবং trusted server থেকে `admin=true` custom claim থাকতে হবে।

গ্রাহকের অর্ডার Firebase Anonymous Auth UID-এর অধীনে তৈরি হয়। Android bridge Firestore থেকে প্রতিটি সক্রিয় পণ্যের বর্তমান মূল্য পুনরায় পড়ে মোট হিসাব করে; গ্রাহকের পাঠানো মোট/মূল্য বিশ্বাস করে না। Admin Panel-এর **অর্ডার** বোতামে অর্ডার দেখা ও Pending/Confirmed/Shipped/Delivered/Cancelled স্ট্যাটাস আপডেট করা যায়।

**গুরুত্বপূর্ণ সীমাবদ্ধতা:** এই ধাপে COD নির্বাচন বাস্তব অর্ডার রেকর্ড করে; bKash/Nagad অপশন এখনও payment gateway নয়। Prescription medicine-এর বিক্রির আগে লাইসেন্স, প্রেসক্রিপশন যাচাই ও pharmacist workflow যোগ করতে হবে। Firebase Console-এ Anonymous provider Enable না করলে অর্ডার জমা হবে না। এই সোর্স ZIP নিজে APK নয়; Build ও বাস্তব Firebase/device test আলাদা করে করতে হবে।

## ধাপ ২৬: Customer Order History
`CUSTOMER-ORDER-TRACKING-BN.md` দেখুন। গ্রাহক `আমার অর্ডার` থেকে নিজের অর্ডার ও status দেখতে পারবেন। Firebase Console-এ এই ZIP-এর `firestore.rules` Publish করতে হবে। Anonymous account uninstall/data clear হলে হারাতে পারে; স্থায়ী cross-device history-এর জন্য phone OTP পরবর্তী ধাপ।

## ধাপ ২৭ — Trusted Cloud Function দিয়ে নিরাপদ Order Total

এই ধাপে অর্ডার তৈরি ও মূল্য গণনা Android client থেকে Firebase Cloud Functions backend-এ সরানো হয়েছে। গ্রাহকের ফোন শুধু product ID ও quantity পাঠায়; backend Firestore থেকে সক্রিয় পণ্যের মূল্য পড়ে মোট হিসাব করে এবং `orders` collection-এ অর্ডার লেখে। Firestore Rules সরাসরি client-এর order create বন্ধ করে।

### একবারের Backend Deployment
1. Firebase Console-এ একই project-এ **Blaze plan** সক্রিয় করুন (Cloud Functions deploy-এর জন্য billing account প্রয়োজন হতে পারে)।
2. কম্পিউটারে Node.js 20 এবং Firebase CLI ইনস্টল করুন: `npm install -g firebase-tools`.
3. এই project folder-এ Terminal খুলে `firebase login` চালান, তারপর `firebase use --add` দিয়ে আপনার Firebase project নির্বাচন করুন।
4. `cd functions` → `npm install` → `cd ..` চালান।
5. `firebase deploy --only functions:createOrder,firestore:rules` চালান।
6. Android Studio-তে project খুলে Gradle Sync করুন; `google-services.json` অবশ্যই `app/` ফোল্ডারে থাকতে হবে।
7. Anonymous Authentication চালু রাখুন; তারপর APK build করে বাস্তব ডিভাইসে অর্ডার পরীক্ষা করুন।

**নিরাপত্তা:** Cloud Function Admin SDK দিয়ে server-side order তৈরি করে। Admin claim, Firebase project config, App Check, rate limiting, abuse monitoring এবং production testing আলাদাভাবে সম্পন্ন করতে হবে। `google-services.json`-এ server private key থাকে না; কোনো Service Account JSON/private key APK বা GitHub-এ দেবেন না। বর্তমানে শুধু Cash on Delivery গ্রহণ করা হয়; bKash/Nagad gateway সংযুক্ত নয়।


## ধাপ ২৮ — Phone OTP Login
`PHONE-OTP-LOGIN-BN.md` অনুসরণ করুন। Firebase Authentication-এ Phone provider Enable, Bangladesh SMS region অনুমোদন, Android SHA-1/SHA-256 যোগ এবং নতুন `google-services.json` ডাউনলোড করতে হবে। Anonymous customer UID-তে Phone credential link করা হয়, যাতে আগের অর্ডারের UID অক্ষুণ্ণ থাকে। একই ফোন নম্বর অন্য account-এ থাকলে স্বয়ংক্রিয় account merge হয় না। বাস্তব SMS এবং Android app verification পরীক্ষা ছাড়া Production release করবেন না।

## ধাপ ২৯ — Customer Profile ও Saved Address
- `customerProfiles/{uid}`-এ ফোন OTP-ভিত্তিক গ্রাহকের নাম ও যাচাইকৃত নম্বর রাখা হয়।
- `customerProfiles/{uid}/addresses`-এ Home/Office delivery address সংরক্ষণ, নির্বাচন ও মুছতে পারবেন।
- `CUSTOMER-PROFILE-ADDRESS-BOOK-BN.md`-এ সেটআপ ও পরীক্ষা নির্দেশনা দেখুন।
- নতুন `firestore.rules` Firebase Console-এ Publish না করলে profile/address feature কাজ করবে না।


## ধাপ ৩০: Admin Customer Management
`ADMIN-CUSTOMER-MANAGEMENT-BN.md` অনুসরণ করুন। নতুন গ্রাহক তালিকা ও customer-wise order history ব্যবহারের আগে `firestore.rules` Publish করুন।

## Seller Management
ধাপ ৩১-এর জন্য `SELLER-MANAGEMENT-BN.md` দেখুন। বিক্রেতা আবেদন করতে Phone OTP Login প্রয়োজন; Admin custom claim দিয়ে আবেদন পর্যালোচনা করবেন। Admin-এর Approved সিদ্ধান্ত সরকারি লাইসেন্স যাচাইয়ের বিকল্প নয়।

## ধাপ ৩২ — Seller Dashboard
`SELLER-DASHBOARD-BN.md` দেখুন। Approved seller নিজের পণ্যের তথ্য Admin Review-এর জন্য জমা দিতে পারবেন। Approved seller product স্বয়ংক্রিয়ভাবে public catalogue-এ প্রকাশিত হয় না; Admin-এর আলাদা যাচাই ও catalogue entry প্রয়োজন।
