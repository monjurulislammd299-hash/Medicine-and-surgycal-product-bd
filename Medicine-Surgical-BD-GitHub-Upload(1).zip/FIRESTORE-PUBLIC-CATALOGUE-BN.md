ধাপ ২৪ — Firestore Public Catalogue

এই আপডেটে:
- Android WebView bridge-এ loadPublicProducts() যুক্ত হয়েছে।
- অ্যাপ চালু হলে Firestore products collection থেকে active == true পণ্য লোড হয়।
- Admin-রা আগের মতোই সব পণ্য দেখতে ও পরিচালনা করতে পারবেন।
- firestore.rules-এ active পণ্যের read/list public করা হয়েছে; create/update/delete শুধু Admin Custom Claim-এ সীমাবদ্ধ।
- Firestore ব্যর্থ হলে আগের LocalStorage/seed catalogue দেখানো থাকবে।

গুরুত্বপূর্ণ:
1. Firebase Console → Firestore Database → Rules-এ এই ZIP-এর firestore.rules প্রকাশ করুন।
2. products collection-এ কেবল গ্রাহকের সামনে দেখানোর উপযোগী তথ্য রাখুন: name, bn, cat, icon, price, desc, active, updatedAt। ব্যক্তিগত/সরবরাহকারী তথ্য এই ডকুমেন্টে রাখবেন না।
3. গ্রাহক অ্যাপ active == true শর্তে query করে; inactive পণ্য দেখাবে না।
4. Firebase project-এর app/google-services.json না থাকলে Android build/Firestore সংযোগ সম্পূর্ণ হবে না।
5. এই পরিবর্তন compile বা বাস্তব Firebase project-এ পরীক্ষা করা হয়নি; Rules publish ও APK build-এর পর ডিভাইসে পরীক্ষা করুন।
6. এটি শুধু পণ্য ক্যাটালগ। বাস্তব অর্ডার, পেমেন্ট, প্রেসক্রিপশন যাচাই এবং লাইসেন্স যাচাই আলাদা নিরাপদ backend workflow চায়।

নিরাপত্তা: Public catalogue read ইচ্ছাকৃত; public read-এ কোনো গোপন তথ্য রাখা যাবে না। Admin custom claim trusted server/Admin SDK থেকে দিতে হবে, Android client থেকে নয়।
