# ধাপ ৩২ — Seller Dashboard

## কী যুক্ত হয়েছে
- Phone OTP-তে লগইন করা বিক্রেতা Seller Dashboard থেকে নিজের আবেদন ও পণ্যের জমার অবস্থা দেখতে পারবেন।
- Admin আবেদন Approved করলে `sellerAccounts/{uid}`-এ অনুমোদনের অবস্থা সংরক্ষিত হয়। Pending/Rejected বিক্রেতা পণ্য জমা দিতে পারবেন না।
- Approved বিক্রেতা পণ্যের নাম, ক্যাটাগরি, মূল্য, স্টক ও বিবরণ জমা দিতে পারবেন।
- জমা দেওয়া পণ্য `sellerProducts`-এ `Pending` অবস্থায় থাকবে; বিক্রেতা শুধু নিজের পণ্য দেখতে পারবেন।
- Admin Panel-এর “বিক্রেতা পণ্য” থেকে পণ্য Approved/Rejected/Pending করা যাবে।

## গুরুত্বপূর্ণ নিরাপত্তা ও প্রকাশনা
- `sellerAccounts` শুধু Admin লিখতে পারবেন; বিক্রেতা নিজের ডকুমেন্ট পড়তে পারবেন।
- `sellerProducts`-এ তৈরি করতে হলে Firebase Auth phone number এবং Approved seller account মিলতে হবে।
- Admin পণ্য Approved করলেই সেটি পাবলিক ক্যাটালগে প্রকাশিত হয় না। বর্তমানে এটি moderation status মাত্র। পাবলিক `products` ক্যাটালগে যোগ করার আগে Admin-কে পণ্যের বৈধতা, লাইসেন্স, মান, মূল্য ও স্টক যাচাই করে আলাদা করে পণ্য তৈরি করতে হবে।
- Seller Application Approved হওয়া সরকারি লাইসেন্স বা DGDA অনুমোদনের বিকল্প নয়। মেডিসিন/সার্জিক্যাল পণ্য বিক্রির আগে প্রযোজ্য DGDA, ফার্মেসি লাইসেন্স, প্রেসক্রিপশন ও ফার্মাসিস্ট তদারকির নিয়ম যাচাই করুন।

## সেটআপ
1. ZIP extract করে Android Studio-তে project খুলুন।
2. Firebase Console-এ `firestore.rules` Publish করুন।
3. Firebase Authentication-এ Phone provider চালু রাখুন; Android app-এর SHA-1/SHA-256 সেট করুন।
4. Admin account-এ trusted Admin SDK/backend দিয়ে `admin=true` custom claim সেট থাকতে হবে।
5. Gradle Sync করে Android build করুন; Firebase config (`google-services.json`) সঠিক app package-এর হতে হবে।

## যাচাইয়ের অবস্থা
- Inline JavaScript `node --check` সফল।
- `functions/index.js` syntax check সফল।
- ZIP integrity check সফল।
- এই পরিবেশে Gradle executable নেই; Kotlin/Android build, Firestore Rules Emulator, Firebase deployment, OTP SMS এবং বাস্তব ডিভাইস পরীক্ষা করা হয়নি।
